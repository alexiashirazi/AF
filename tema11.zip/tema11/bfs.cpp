﻿#include <stdlib.h>
#include <string.h>
#include "bfs.h"
#include <stack>
#include <queue>


/*
* NUME:SHIRAZI ALEXIA, grupa 30225 calculatoare romana
* functia: get_neighbours  --are complexitatea O(1) deoarece trece printr-un array de patru elemente pentru a 
*          gasi vecinii intr-un punct fix
*           aceasta functie primeste ca intrare reprezentarea tip grila si un punct ca intrare si completeaza 
*           un array cu vecinii punctului dat in grila. Evita vecinii care sunt in afara limitei grilei sau care
*           se afla in perete
* functia bfs: are complexitatea O(V+E) unde V=noduri si E=muchii, deoarece fiecare nod si muchie este
*               vizitat o singura data.
*               Algoritmul de parcurgere în lățime (Breadth-First Search) este implementat în această funcție.
*                Explorează graful pornind de la un nod sursă dat, marcând nodurile atinse și calculând distanțele de la sursă. 
*               Folosește o coadă pentru traversare.
* 
*  print_pretty_t1- are complexitatea O(n) deoarece fiecare nod este parcurs o data
*                   Această funcție este o funcție ajutătoare pentru a tipări un arbore într-un format mai ușor de citit.
*                Tipărește recursiv arborele, pornind de la nodul rădăcină specificat, cu un nivel de indentare specificat.
*                   
*  shortest path- are complexitatea O(V+E) unde v sunt nodurile si E muchiile deoarece se 
 *               apeleaza functia bfs care reconstruieste cel mai scurt drum , fiind parcurse o data
 *               toate nodurile si muchiile
 *                Această funcție calculează cel mai scurt drum între două noduri (start și end) în graf folosind algoritmul BFS. 
 *                Returnează nodurile de-a lungul celui mai scurt drum în tabloul furnizat si numarul lor.
 *
*/

int get_neighbors(const Grid *grid, Point p, Point neighb[])
{

    int k = 0;

    //coordonatele tuturor posibilelor pozitii
    int pozitii[4][2] = { {-1, 0}, {1, 0}, {0, -1}, {0, 1} };

    for (int i = 0; i < 4; ++i) {
        int rand = p.row + pozitii[i][0];
        int coloana = p.col + pozitii[i][1];

        // verificam daca pozitia este in interiorul grid-ului
        if (rand >= 0 && rand < grid->rows && coloana >= 0 && coloana < grid->cols) {
            // vericam daca pozitia nu este un perete
            if (grid->mat[rand][coloana] == 0) {
                // adaugam vecinul
                neighb[k].row = rand;
                neighb[k].col = coloana;
                k++;
            }
        }
    }

    return k;

   
}

void grid_to_graph(const Grid *grid, Graph *graph)
{
    //we need to keep the nodes in a matrix, so we can easily refer to a position in the grid
    Node *nodes[MAX_ROWS][MAX_COLS];
    int i, j, k;
    Point neighb[4];

    //compute how many nodes we have and allocate each node
    graph->nrNodes = 0;
    for(i=0; i<grid->rows; ++i){
        for(j=0; j<grid->cols; ++j){
            if(grid->mat[i][j] == 0){
                nodes[i][j] = (Node*)malloc(sizeof(Node));
                memset(nodes[i][j], 0, sizeof(Node)); //initialize all fields with 0/NULL
                nodes[i][j]->position.row = i;
                nodes[i][j]->position.col = j;
                ++graph->nrNodes;
            }else{
                nodes[i][j] = NULL;
            }
        }
    }
    graph->v = (Node**)malloc(graph->nrNodes * sizeof(Node*));
    k = 0;
    for(i=0; i<grid->rows; ++i){
        for(j=0; j<grid->cols; ++j){
            if(nodes[i][j] != NULL){
                graph->v[k++] = nodes[i][j];
            }
        }
    }

    //compute the adjacency list for each node
    for(i=0; i<graph->nrNodes; ++i){
        graph->v[i]->adjSize = get_neighbors(grid, graph->v[i]->position, neighb);
        if(graph->v[i]->adjSize != 0){
            graph->v[i]->adj = (Node**)malloc(graph->v[i]->adjSize * sizeof(Node*));
            k = 0;
            for(j=0; j<graph->v[i]->adjSize; ++j){
                if( neighb[j].row >= 0 && neighb[j].row < grid->rows &&
                    neighb[j].col >= 0 && neighb[j].col < grid->cols &&
                    grid->mat[neighb[j].row][neighb[j].col] == 0){
                        graph->v[i]->adj[k++] = nodes[neighb[j].row][neighb[j].col];
                }
            }
            if(k < graph->v[i]->adjSize){
                //get_neighbors returned some invalid neighbors
                graph->v[i]->adjSize = k;
                graph->v[i]->adj = (Node**)realloc(graph->v[i]->adj, k * sizeof(Node*));
            }
        }
    }
}

void free_graph(Graph *graph)
{
    if(graph->v != NULL){
        for(int i=0; i<graph->nrNodes; ++i){
            if(graph->v[i] != NULL){
                if(graph->v[i]->adj != NULL){
                    free(graph->v[i]->adj);
                    graph->v[i]->adj = NULL;
                }
                graph->v[i]->adjSize = 0;
                free(graph->v[i]);
                graph->v[i] = NULL;
            }
        }
        free(graph->v);
        graph->v = NULL;
    }
    graph->nrNodes = 0;
}

void bfs(Graph *graph, Node *s, Operation *op)
{
    
    if (op != NULL) {
        op->count();
    }

    if (graph == NULL || s == NULL) {
        
        return;
    }

    // initializarea tuturor nodurilor din graf
    for (int i = 0; i < graph->nrNodes; ++i) {
        if (op != NULL)
        op->count(3);
        graph->v[i]->color = COLOR_WHITE;
        graph->v[i]->dist = -1;  
        graph->v[i]->parent = NULL;
    }

    // setam nodul sursa ca fiind descoperit
    if (op != NULL)
    op->count(3);
    s->color = COLOR_GRAY;
    s->dist = 0;
    s->parent = NULL;

    // initializam coada pt bfs
    std::queue<Node*> q;
    q.push(s);

    while (!q.empty()) { //in q sunt stocate toata nodurile gri
        // scoatem din coada primul nod 
        Node* u = q.front();
        q.pop();

       
       
        //toate nodurile din lista de adiacenta a lui u
        for (int i = 0; i < u->adjSize; i++)
        {
            if (op != NULL)
            op->count();
            Node* v = u->adj[i];
            if (op != NULL)
            op->count();
            // verificam daca am mai vizitat nodul
            if (v->color == COLOR_WHITE) {
                // marcam nodul ca fiind vizitat
                if (op != NULL)
                op->count(3);
                v->color = COLOR_GRAY;
                v->dist = u->dist + 1;
                v->parent = u;

                // introducem nodul in coada 
                q.push(v);
            }
        }

        // coloram nodul ca fiind vizitat, adica in negru
        if (op != NULL)
        op->count();
        u->color = COLOR_BLACK;
    }
    
}

void print_pretty_T1(int *parent, Point *representasion, int root, int n, int space)
{
        int j = 0;
        while (j < space) {
            printf(" ");
            j++;
        }
        printf("(%d, %d)\n", representasion[root].row, representasion[root].col);
        for (int i = 0; i < n; i++) {
            if(parent[i]==root)
            print_pretty_T1(parent,representasion,i,n,space+3);
        }
    
}

void print_bfs_tree(Graph *graph)
{
    //first, we will represent the BFS tree as a parent array
    int n = 0; //the number of nodes
    int *p = NULL; //the parent array
    Point *repr = NULL; //the representation for each element in p

    //some of the nodes in graph->v may not have been reached by BFS
    //p and repr will contain only the reachable nodes
    int *transf = (int*)malloc(graph->nrNodes * sizeof(int));
    for(int i=0; i<graph->nrNodes; ++i){
        if(graph->v[i]->color == COLOR_BLACK){
            transf[i] = n;
            ++n;
        }else{
            transf[i] = -1;
        }
    }
    if(n == 0){
        //no BFS tree
        free(transf);
        return;
    }

    int err = 0;
    p = (int*)malloc(n * sizeof(int));
    repr = (Point*)malloc(n * sizeof(Node));
    for(int i=0; i<graph->nrNodes && !err; ++i){
        if(graph->v[i]->color == COLOR_BLACK){
            if(transf[i] < 0 || transf[i] >= n){
                err = 1;
            }else{
                repr[transf[i]] = graph->v[i]->position;
                if(graph->v[i]->parent == NULL){
                    p[transf[i]] = -1;
                }else{
                    err = 1;
                    for(int j=0; j<graph->nrNodes; ++j){
                        if(graph->v[i]->parent == graph->v[j]){
                            if(transf[j] >= 0 && transf[j] < n){
                                p[transf[i]] = transf[j];
                                err = 0;
                            }
                            break;
                        }
                    }
                }
            }
        }
    }
    free(transf);
    transf = NULL;

    if(!err){
       
        
        for (int i = 0; i < n; ++i) {
            if (p[i] == -1)
            {
                print_pretty_T1(p, repr, i, n, 0);
            }
        }

        
    
    }

    if(p != NULL){
        free(p);
        p = NULL;
    }
    if(repr != NULL){
        free(repr);
        repr = NULL;
    }
}

int shortest_path(Graph *graph, Node *start, Node *end, Node *path[])
{
   
    if (start == NULL || end == NULL)
        return -1;

    // Folosiți funcția bfs pentru a găsi drumul minim
    bfs(graph, start, NULL);

    // Verificați dacă end este atins de la start
    if(end->color != COLOR_BLACK) {
        return -1; // Nu există un drum între start și end
    }

    // Reconstruirea drumului
    int lung = 0;
    Node* p = end;


    //mergem de la sfarsit la start si stocam 
    while (p != NULL) {
        path[lung] = p;
        lung++;
        p = p->parent;
    }

    //reverse
    for (int i = 0; i < lung / 2; i++) {
        Node* aux = path[i];
        path[i] = path[lung - i - 1];
        path[lung - i - 1] = aux;
    }

    return lung;

}

//functie de ahaugat muchie intre doua noduri date
void addEdge(Node* source, Node* destination) {
    
    for (int i = 0; i < source->adjSize; ++i) {
        //verificam daca muchia exista, daca da , dam return
        if (source->adj[i] == destination) {
            return;  
        }
    }

    
    //daca nu exista adaugam nodul de destinatie la lista de adiacenta a nodului sursa
    source->adj = (Node**)realloc(source->adj, (source->adjSize + 1) * sizeof(Node*));
    source->adj[source->adjSize] = destination;
    source->adjSize++;
}

// verificam daca exista muchie intre cele doua noduri
bool edgeExists(Node* source, Node* destination) {
    for (int i = 0; i < source->adjSize; ++i) {
        if (source->adj[i] == destination) {
            return true;  
            // muchia exista
        }
    }
    return false; 
    // muchia nu exista
}


// generam muchii random
void generateRandomEdges(Graph* graph, int numEdges) {
    for (int j = 0; j < numEdges; ++j) {
       
        int i;
        FillRandomArray(&i, 1, 1, graph->nrNodes-1, 0, 0);
        int source = i; //un numar pentru nodul sursa
        FillRandomArray(&i, 1, 1, graph->nrNodes-1, 0, 0);
        int destination = i; //un numar pentru nodul destinatie
        while (source == destination || edgeExists(graph->v[source], graph->v[destination])) {
            //verificam sa nu fie sursa egala cu destinatia sau sa nu existe deja o muchie
            FillRandomArray(&i, 1, 1, graph->nrNodes - 1, 0, 0);
            destination = i;
        }
        
        //adaugam muchia intre cele doua noduri
        addEdge(graph->v[source], graph->v[destination]);
    }
}

//in aceasta functie ne asiguram ca graful e conex
void connectVerticesSequentially(Graph* graph) {
    for (int j = 1; j < graph->nrNodes; ++j) {
        addEdge(graph->v[j - 1], graph->v[j]);
    }
}
void performance()
{
    int n, i;
    Profiler p("bfs");

    
    for (int j = 0; j < 5; j++) {
        for (n = 1000; n <= 4500; n += 100) {
            Operation op = p.createOperation("bfs-edges", n);
            Graph graph;
            graph.nrNodes = 100;
            //initialize the nodes of the graph
            graph.v = (Node**)malloc(graph.nrNodes * sizeof(Node*));
            for (i = 0; i < graph.nrNodes; ++i) {
                graph.v[i] = (Node*)malloc(sizeof(Node));
                memset(graph.v[i], 0, sizeof(Node));
            }
           

            generateRandomEdges(&graph, n);
            connectVerticesSequentially(&graph);
            bfs(&graph, graph.v[0], &op);
            free_graph(&graph);
        }
    }
    p.divideValues("bfs-edges", 5);

    
    for (int j = 0; j < 5; j++) {
        for (n = 100; n <= 200; n += 10) {
            Operation op = p.createOperation("bfs-vertices", n);
            Graph graph;
            graph.nrNodes = n;
          
            graph.v = (Node**)malloc(graph.nrNodes * sizeof(Node*));
            for (i = 0; i < graph.nrNodes; ++i) {
                graph.v[i] = (Node*)malloc(sizeof(Node));
                memset(graph.v[i], 0, sizeof(Node));
            }
           
            generateRandomEdges(&graph, 4500);
            connectVerticesSequentially(&graph);

            bfs(&graph, graph.v[0], &op);
            free_graph(&graph);
        }
    }
    p.divideValues("bfs-vertices",5);

    p.showReport();
}
