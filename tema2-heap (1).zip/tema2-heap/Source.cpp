﻿#include <stdio.h>
#include <stdlib.h>
#include "profiler.h"

/*

NUME SI PRENUME: SHIRAZI ALEXIA
UNIVERSITATEA TEHNICA DIN CLUJ NAPOCA, CALCULATOARE ROMANA ANUL 2 GRUPA 30225
TEMA: Analiza și Compararea a două metode
de construire a structurii de date Heap: “De jos în
sus” (Bottom-up) vs. “De sus în jos” (Top-down)

Am implementat metoda de construire bottom-up astfel:
am creat functia heapify( care aduce maximul inspre radacina)
Fiecare apel al functiei heapify este de O(lgn) iar functia 
bottom_up_heap va face O(n) apeluri( O(n/2) pentru ca merge doar jumatate
deci complexitatea va fi de O(nlgn)

functia heap increase key compara repetat elementele cu parintii
daca noua valoare depaseste valoarea parintelui reface structura heap
(ca radacina sa fie maxima)
complexitatea este de O(lgn)

Max Heap Insert practic insereaza un nou element in heap
Prima data se adauga o "frunza" si apoi se apeleaza heap increase key ca sa 
seteze cheia nodului. Aceasta functie are complexitatea O(lgn)
functia top down heap apeleaza de n ori max heap insert deci per total
metoda top down de construire va avea complexitatea O(nlgn)


In cazul mediu statistic bottom up are mult mai putine atribuiri decar top down, foarte
mica diferenta la comparari, bottom up depasind putin dar per total
bottom up este mai eficient

In cazul defavorabil, vectorul initial este sortat crescator, fiindca e nevoie de
un numar maxim de pasi ca elementul maxim sa ajunga la radacina. In acest caz e foarte 
vizibil ca top down este mai putin eficient decat botttom up


In concluzie, algoritmul de bottom up este mai eficient decat top down
(nu cu mult dar vizibil). I
*/
Profiler p("heap-uri");
int left_child(int i)
{ //retyrnam copilul din stanga
	return 2 * i + 1;
}
int right_child(int i)
{//returnam copilul din dreapta
	return 2 * i + 2;

}
int parent(int i)
{//returnam parintele lui i
	return (i - 1) / 2;
}
void heapify(int v[], int n, int i)
{
	Operation opattr = p.createOperation("bottom_up_atr", n); //am creat operatie de atribuire
	Operation opcomp = p.createOperation("bottom_up_comp", n); //am creat operatia de comparare
	int largest = 0;
	int left = left_child(i);
	int right = right_child(i);
	opcomp.count();
	//la fiecare pas se determina maximul dintre v[i] v[stanga] si v[dreapta]
	//si se stocheaza indexul in largest
	//daca indexul lui a[i] este in largest nu e nevoie de interschimbare
	//daca largest este diferit de i inseamna ca nodul curent nu are cea mai mare valoare 
	///comparativ cu el si copiii sai 

	if (left<n && v[left]>v[i])
	{
		largest = left;
	}
	else
	{
		largest = i;
	}
	opcomp.count();
	if (right < n && v[right] > v[largest])
		largest = right;
	if (largest != i)
	{
		opattr.count();
		int aux = v[i];
		v[i] = v[largest];
		v[largest] = aux;
		//facem apel recursiv
		heapify(v, n, largest);

	}
	p.addSeries("bottom_up_total", "bottom_up_atr", "bottom_up_comp");
}
void bottom_up_heap(int v[], int n)
{
	for (int i = n / 2 - 1; i >= 0; i--)
		heapify(v, n,i);
	//p.addSeries("bottom_up_total", "bottom_up_atr", "bottom_up_comp");
}


void heap_increase_key(int v[], int i, int key, int n, int nr) {
	p.countOperation("top_down_atr", nr);
	v[i] = key;
	p.countOperation("top_down_comp", nr);
	//daca parintele are valoare mai mica decat copilul se interschimba
	while (i > 0 && v[(i - 1) / 2] < v[i]) {
		p.countOperation("top_down_comp", nr);
		p.countOperation("top_down_atr", nr);
		int aux = v[i];
		v[i] = v[(i - 1) / 2];
		v[(i - 1) / 2] = aux;
		i = (i - 1) / 2;
	}
}

void max_heap_insert(int v[], int n, int key, int nr) {
	int index = n;
	p.countOperation("top_down_atr", nr);
	v[index] = key;
	heap_increase_key(v, index, key, n, nr);
}

void top_down_heap(int v[], int n) {
	for (int i = 1; i < n; i++) {
		max_heap_insert(v, i, v[i], n);
	}
	p.addSeries("top_down_total", "top_down_atr", "top_down_comp");
}

void heapsort(int v[], int n)
{
	//bottom_up_heap(v, n);
	for (int i = n - 1; i >= 0; i--)
	{
		//mergem de la sfarsit deoarece acolo este cel mai mic element si
		//facem schimb cu cel de la radacina (care e maximul)
		int aux = v[0];
		v[0] = v[i];
		v[i] = aux;

		heapify(v, i, 0);
		//se reface heap ul
	}
}


void print_heap(int v[], int n)
{
	printf("heap-ul rezultat este:\n");
	for (int i = 0; i < n; i++)
		printf("%d ", v[i]);
	printf("\n");
}
int main()
{
	

	int k, m;
	int n, v[100];
	int sir[10000];
	int copie[10000];
	printf("pentru demo apasati 1, iar pentru grafic 2\n");
	scanf_s("%d", &k);
	if (k == 1)
	{

		printf("introduceti numarul de elemente\n");
		scanf_s("%d", &n);
		printf("introduceti elementele din vector\n");
		for (int i = 0; i < n; i++)
			scanf_s("%d", &v[i]);

		printf("pentru bottom_up apasati 1, pentru top down apasati 2\n");
		scanf_s("%d", &m);
		if (m == 1)
		{
			bottom_up_heap(v, n);
			print_heap(v, n);
			printf("\n dupa heapsort:\n");
			heapsort(v, n);
			print_heap(v, n);
		}
		else
		{
			printf("\n");
			top_down_heap(v, n);

			print_heap(v, n);
			printf("\n dupa heapsort:\n");
			heapsort(v, n);
			print_heap(v, n);
		}

	}
	else
	{
		//caz mediu statistic
		for (int h = 0; h < 5; h++)
			for (int i = 100; i <= 10000; i = i + 100)
			{
				//genearam un array random 
				FillRandomArray(sir, i, 10, 50000, 1, 0);
				//facem copie de fiecare data pentru a nu strica sirul
				CopyArray(copie, sir, i);
				bottom_up_heap(copie, i);
				CopyArray(copie, sir, i);
				top_down_heap(copie, i);
			}
		//impartim la 5 deoarece avem 5 experimente
		p.divideValues("bottom_up_comp", 5);
		p.divideValues("bottom_up_atr", 5);
		p.divideValues("bottom_up_total", 5);
		p.divideValues("top_down_atr", 5);
		p.divideValues("top_down_comp", 5);
		p.divideValues("top_down_total", 5);

		p.createGroup("Mediu_numar_atriburi", "bottom_up_atr", "top_down_atr");
		p.createGroup("Mediu_numar_comparatii", "bottom_up_comp", "top_down_comp");
		p.createGroup("Mediu_total", "bottom_up_total", "top_down_total");

		p.reset("caz_defavorabil");
		//caz defavorabil
		for (int i = 100; i <= 10000; i = i + 100)
		{
			FillRandomArray(sir, i, 10, 50000, 1, 1);
			CopyArray(copie, sir, i);
			bottom_up_heap(copie, i);
			CopyArray(copie, sir, i);
			top_down_heap(copie, i);
		}
		p.createGroup("Defavorabil_atribuiri", "bottom_up_atr", "top_down_atr");
		p.createGroup("Defavorabil_comparatii", "bottom_up_comp", "top_down_comp");
		p.createGroup("Defavorabil_total", "bottom_up_total", "top_down_total");

		p.showReport();
	}

	return 0;
}