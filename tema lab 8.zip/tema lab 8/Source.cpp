﻿#include <stdio.h>
#include <stdlib.h>
#include "Profiler.h"

Profiler p("tema8");


/*
*    NUME: SHIRAZI ALEXIA
*   CALCULATOARE ROMANA SERIA A, GRUPA 30225
    CERINTA:
    Se cere implementarea corectă și eficientă a parcurgerii iterative si recursive al unui arbore binar,
    respectiv hibridizare pentru quicksort

    Am folosit pentru parcurgea arborelui inorder
    Atat varianta iterativa cat si cea recursiva are complexitatea O(n)- unde n reprezinta numarul de elemente
    Fiecare nod este vizat o singura data, de unde rezulta si complexitatea
    Comparativ, parcurgea recursiva este mai buna deoarece este mai usor de implementat si este mai clara

    Quicksort vs Hybrid
    Complexitatea quicksort htbrid este in medie O(nlogn) dar in cel mai rau caz 
    ajunge la O(n^2)
    cu toate acestea, subsecventele mici vor fi sortate prin sortarea prin insertie, adica sub prag O(n^2)
    Iar subsecventele mari vor fi sortate prin quicksort, care are complexitatea O(nlogn)

    Pragul optim de hibridizare gasit de mine este 7.
    am creat un grafic pe care am pus insertion sort cu quicksort, iar unde se desparteau 
    acolo era pragul. Adica momentul in care unul era mai eficient decat celalalt.

*/
typedef struct NodeT {
    int key;
    struct NodeT* left;
    struct NodeT* right;
} NodeT;

const int MAX_SIZE = 1000;

NodeT* BuildTree(int left, int right) {
    if (left > right) {
        return NULL;
    }
    else {
        NodeT* root = (NodeT*)malloc(sizeof(NodeT));
        int mid = (left + right) / 2;
        root->key = mid;
        root->left = BuildTree(left, mid - 1);
        root->right = BuildTree(mid + 1, right);
        return root;
    }
}




void inorder_rec_perf(NodeT* root, Operation *op) {
    if (root == NULL)
        return;

    inorder_rec_perf(root->left, op);
    op->count();
    inorder_rec_perf(root->right, op);
}

void inorder_rec(NodeT* root) {
    if (root == NULL)
        return;

    inorder_rec(root->left);
    printf("%d ", root->key);
    
    inorder_rec(root->right);
}
void inorder_it(NodeT* root) {
    NodeT* vec[MAX_SIZE]; //vector de pointeri
    int index = -1; //pentru evidenta "stivei"
    NodeT* p = root;
    while (p != NULL || index != -1) { //cat timp nu am ajuns la final si daca mai avem in stiva ceva
        while (p != NULL) {
            index++; //parcurgem subarborele stang si adaugam in vector fiecare nod pana cand nu mai exista
            vec[index] = p;
            p = p->left;
        }
        //cand se iese din while, inseamna ca nu mai exista noduri in stanga
        //scoartem un nod din vector si il afisam
        p = vec[index];
        index--;
        printf("%d ", p->key);
        //se trece la subarborele drept si procesul este repetat pana cand fiecare nod este vizitat
        p = p->right;
    }
}

void inorder_it_perf(NodeT* root, Operation *op) {
    NodeT* vec[MAX_SIZE];
    int index = -1;
    NodeT* p = root;
    while (p != NULL || index != -1) {
        while (p != NULL) {
            index++;
            vec[index] = p;
            p = p->left;
        }

        p = vec[index];
        index--;
        op->count();
        p = p->right;
    }
}

void insertion_sort(int v[], int n, Operation* opcomp, Operation* opattr) {
    int i, j;
    for (i = 1; i < n; i++) {
        j = i - 1;
        int aux = v[i];
        opcomp->count();
        while (aux < v[j] && j >= 0) {
            opcomp->count();
            opattr->count();
            v[j + 1] = v[j];
            j--;
        }
        j++;
        opattr->count();
        v[j] = aux;
    }
}

void insertion_sort_wh(int v[], int n) {
    int i, j;
    for (i = 1; i < n; i++) {
        j = i - 1;
        int aux = v[i];
        while (aux < v[j] && j >= 0) {
            
            v[j + 1] = v[j];
            j--;
        }
        j++;
      
        v[j] = aux;
    }
}



int partition_quicksort(int v[], int p, int r, Operation* opcomp, Operation* opattr) {
    int aux;
    int x = v[r];
    int i = p - 1;
    for (int j = p; j <= r - 1; j++) {
        opcomp->count();
        if (v[j] <= x) {
            i++;
            opattr->count();
            aux = v[i];
            v[i] = v[j];
            v[j] = aux;
        }
    }
    aux = v[i + 1];
    opattr->count();
    v[i + 1] = v[r];
    opattr->count();
    v[r] = aux;
    return i + 1;
}


int partition_quicksort_wh(int v[], int p, int r) {
    int aux;
    int x = v[r];
    int i = p - 1;
    for (int j = p; j <= r - 1; j++) {
       
        if (v[j] <= x) {
            i++;
     
            aux = v[i];
            v[i] = v[j];
            v[j] = aux;
        }
    }
    aux = v[i + 1];

    v[i + 1] = v[r];
  
    v[r] = aux;
    return i + 1;
}

void quicksort(int v[], int p, int r, Operation* opcomp, Operation* opattr) {
    if (p < r) {
        int q = partition_quicksort(v, p, r, opcomp, opattr);
        quicksort(v, p, q - 1, opcomp, opattr);
        quicksort(v, q + 1, r, opcomp, opattr);
    }
}

void quicksort_wh(int v[], int p, int r) {
    if (p < r) {
        int q = partition_quicksort_wh(v, p, r);
        quicksort_wh(v, p, q - 1);
        quicksort_wh(v, q + 1, r);
    }
}

void quick_sort_hybrid(int v[], int left, int right, Operation* opcomp, Operation* opattr) {
    if (right - left + 1 < 7) //pragul gasit de mine este 7
    { //pentru un numar mic de elemente intra pe insertion sort
        insertion_sort(v+left, right - left + 1, opcomp, opattr);
    }
    else {
        if (left < right) {
            //apelam partion pentru a stabili pivotul
            int piv = partition_quicksort(v, left, right, opcomp, opattr);
            //aplicam divide et impera
            quick_sort_hybrid(v, left, piv - 1, opcomp, opattr);


            quick_sort_hybrid(v, piv + 1, right, opcomp, opattr);
        }
        
    }
}


void quick_sort_hybrid_wh(int v[], int left, int right) {
    if (right - left + 1 <= 7) {
        insertion_sort_wh(v+left, right - left + 1);
    }
    else {
        if (left < right) {
            int piv = partition_quicksort_wh(v, left, right);

            quick_sort_hybrid_wh(v, left, piv - 1);



            quick_sort_hybrid_wh(v, piv + 1, right);

        }
    }
}
int main() {
    int choice = 1;

    if (choice == 1) {
        int v[100];
        int n;
        int x;
        printf("pt build tree dati numarul de elemente\n");
        scanf_s("%d", &x);
        printf("\n");
        NodeT* root = (NodeT*)malloc(sizeof(NodeT));
        root = BuildTree(1, x);
        printf("arborele este:\n");
        inorder_rec(root);
        printf("\n introduceti numarul de elemente pentru sortarea vectorului\n");
        scanf_s("%d", &n);
        for (int i = 0; i < n; i++)
            scanf_s("%d", &v[i]);
        Operation opcomp = p.createOperation("opcomp", n);
        Operation opattr = p.createOperation("opattr", n);
        quick_sort_hybrid_wh(v, 0, n - 1);

        for (int i = 0; i < n; i++)
            printf("%d ", v[i]);
    }
    else {
        int v[10001];
        int copy[10001];

        //for (int i = 100; i <= 10000; i = i + 100) {
        //    FillRandomArray(v, i, 10, 50000, 1, 0);
        //    Operation opcomp1 = p.createOperation("opcomp1", i);
        //    Operation opattr1 = p.createOperation("opattr1", i);
        //    Operation opcomp2 = p.createOperation("opcomp2", i);
        //    Operation opattr2 = p.createOperation("opattr2", i);
        //    CopyArray(copy, v, i);
        //    insertion_sort(copy, i, &opcomp1, &opattr1);
        //    CopyArray(copy, v, i);
        //    quicksort(copy, 0, i - 1, &opcomp2, &opattr2);
        //}

        //p.createGroup("comparatii", "opcomp1", "opcomp2");
        //p.createGroup("atribuiri", "opattr1", "opattr2");
        //p.addSeries("total_insertion", "opcomp1", "opattr1");
        //p.addSeries("total_quick", "opcomp2", "opattr2");
        //p.createGroup("total", "total_insertion", "total_quick");
        //p.showReport();
        int x;
        for (int k = 0; k < 5; k++) {
            for (int i = 100; i <= 10000; i = i + 100)
            {
                NodeT* root = (NodeT*)malloc(sizeof(NodeT));
                root = BuildTree(1, i);
                Operation op1 = p.createOperation("recursiv", i);
                Operation op2 = p.createOperation("iterativ", i);
                inorder_rec_perf(root, &op1);
                inorder_it_perf(root, &op2);
            }
        }
        p.divideValues("op1", 5);
        p.divideValues("op2", 5);

        //p.createGroup("inorder", "recursiv", "iterativ");
        
        p.reset("quicksort vs quicksort hybrid");
       
        for (int j = 0; j < 1000; j++) {
            for (int i = 100; i <= 10000; i = i + 100) {
                FillRandomArray(v, i, 10, 50000, 1, 0);
                Operation opcomp1 = p.createOperation("opcomp1", i);
                Operation opattr1 = p.createOperation("opattr1", i);
                Operation opcomp2 = p.createOperation("opcomp2", i);
                Operation opattr2 = p.createOperation("opattr2", i);
                CopyArray(copy, v, i);
                quicksort(copy, 0, i - 1, &opcomp1, &opattr1);
                CopyArray(copy, v, i);
                quick_sort_hybrid(copy, 0, i - 1, &opcomp2, &opattr2);
            }
        }
        p.divideValues("opcomp1", 1000);
        p.divideValues("opcomp2", 1000);
        p.divideValues("opattr1", 1000);
        p.divideValues("opattr2", 1000);

        p.createGroup("comparatii", "opcomp1", "opcomp2");
        p.createGroup("atribuiri", "opattr1", "opattr2");
       // p.addSeries("total", "comparatii", "atribuiri");
        p.addSeries("Total_quick", "opcomp1", "opattr1");
        p.addSeries("Total_hyb_quick", "opcomp2", "opattr2");


        p.createGroup("total", "Total_quick", "Total_hyb_quick");


        for (int i = 100; i <= 10000; i = i + 100)
        {
            FillRandomArray(v, i, 10, 50000, 0, 0);

            p.startTimer("timp_quicksort", i);
            for (int test = 0; test < 1000; test++)
            {

                CopyArray(copy, v, i);

                quicksort_wh(copy, 0, i - 1);
                
            }
            p.stopTimer("timp_quicksort", i);

            p.startTimer("timp_hybrid", i);
            for (int test = 0; test < 1000; test++)
            {
                CopyArray(copy, v, i);

                quick_sort_hybrid_wh(copy, 0, i - 1);
            }
            p.stopTimer("timp_hybrid", i);

        }

        p.divideValues("timp_quicksort", 1000);
        p.divideValues("timp_hybrid", 1000);
        p.createGroup("time", "timp_quicksort", "timp_hybrid");


        p.showReport();
    }

    return 0;
}