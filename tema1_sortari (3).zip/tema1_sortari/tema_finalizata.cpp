#include <stdio.h>
#include <stdlib.h>
#include "Profiler.h"

Profiler p("sortari");


/*
NUME: Shirazi Alexia
	Universitatea Tehnica din Cluj Napoca, Calculatoare romana , anul 2 grupa 30225, semigrupa 2
	
	S-a cerut analiza celor 3 metode de sortare: bubble_sort, insertion_sort si selection_sort
	In cazul favorabil:
	Metoda Bubble sort are complexitatea O(n), deoarece nu se face nicio atribuire atunci cand se parcurge, ci doar comparari(sirul e deja sortat)
	Se vor face comparari pentru a se verifica daca e nevoie de interschimbari 

	Metoda Insertion sort va avea complexitatea O(n), sirul fiind deja sortat, se vor face doar comparari fara atribuiri

	Metoda Selection Sort va avea complexitatea O(n^2) ( sirul fiind deja sortat), adica nu va fi nevoie de interschimbare
	In cazul de fata, favorabil, primul for va efectua n-1 iteratii, iar bucla interna va efectua n-i-1 operatii deci se vor face n*(n-1)/2 comparatii

	Caz mediu statistic:
	Metoda Bubble-sort va avea complexitatea O(n^2) atunci cand avem un sir random deoarece se vor face aproximativ N^2/2 comparatii si atribuiri

	Metoda Insertion sort va avea complexitatea O(N^2)  deoarece se fac aproximativ n^2/4 comparari si atribuiri. De obicei un element va trebui
	comparat cu aproximativ jumatate dintre elementele din partea sirului sortat

	Metoda Selection sort va avea complexitatea O(n^2); pt fiecare element din partea nesortata 
	se vor face in medie n/2 comparatii pt a gasii minimul si pt ca sunt n elemente intr un sir 
	vom avea N^2/2

	Caz Defavorabil:
	Metoda Bubble sort  si Insertion sort va avea complexitea O(N^2) deoarece se fac n^2 comparatii si atribuiri (sir sortat descrescator), fiind
	nevoie de un numar maxim de comparatii si atribuiri

	metoda defavorabila la selection sort este sirul crescator shiftat la dreapta cu o pozitie
	( ex 5 1 2 3 4) si va avea complexitatea o(N^2) fiind nevoie in medie N^2/2 comparari si atribuiri

*/
void bubble_sort(int v[], int n)
{
	Operation opattr = p.createOperation("bubblesort_atribuiri", n); //am creat operatie de atribuire
	Operation opcomp = p.createOperation("bubblesort_comparari", n); //am creat operatia de comparare
	int i;
	int sortat;
	do
	{
		sortat = 1;
		for (i = 0; i < n - 1; i++)
		{
			opcomp.count(); //comparatia v[i] cu v[i+1]
			if (v[i] > v[i + 1])
			{
				opattr.count(3); //atribuirea de 3 ori pt interschimbare
				int aux = v[i];
				v[i] = v[i + 1];
				v[i + 1] = aux;
				sortat = 0;
			}
			
		}
		n--; //am scazut n pentru a nu mai merge pana la final
	} while (!sortat);
	p.addSeries("bubblesort_total", "bubblesort_atribuiri", "bubblesort_comparari"); 
}
void insertion_sort(int v[], int n)
{
	Operation opattr = p.createOperation("insertionsort_atribuiri", n);
	Operation opcomp = p.createOperation("insertionsort_comparari", n);
	int i, j;
	for (i = 1; i < n; i++)
	{
		 j = i - 1;
		 opattr.count();
		 int aux = v[i]; //presupunem ca primul element este partea sirului sortat
		 opcomp.count(); //am comparat aici pt cazul in care nu intra in while
			//mutam cu cate o pozitie fiecare element care este mai mare decat aux
		 while (aux < v[j] && j >= 0)
		 {
			 opcomp.count(); //compar aux cu v[j] 
			 opattr.count();
			 v[j + 1] = v[j];
			 j--;

		 }
		 j++;
		 opattr.count();
		 v[j] = aux; //practic pun pe v[j+1] auxul
	}
	p.addSeries("insertionsort_total", "insertionsort_atribuiri", "insertionsort_comparari");
}
void selection_sort(int v[], int n)
{
	Operation opattr = p.createOperation("selectionsort_atribuiri", n);
	Operation opcomp = p.createOperation("selectionsort_comparari", n);
	int minimum = 0;
	int aux;
	for (int i = 0; i < n - 1; i++)
	{
		minimum = i; //consideram primul element ca fiind minim
		for (int j = i + 1; j < n; j++)
		{
			opcomp.count();
			if (v[j] < v[minimum])
				minimum = j; //daca gasim un alt element mai mic decat minim actualizam pozitia
		}
		if (minimum != i)
		{ //daca cumva s-a actualizat pozitia si minimul nu mai este pe pozitia i interschimbam v[i] cu v[minimum]
			opattr.count(3);
			aux = v[i];
			v[i] = v[minimum];
			v[minimum] = aux;
		}
	}
	p.addSeries("selectionsort_total", "selectionsort_atribuiri", "selectionsort_comparari");
}
void demo(int v[], int n, int choice)
{
	if (choice == 1)
		bubble_sort(v, n);
	else
	{
		if (choice == 2)
			insertion_sort(v, n);
		else
			selection_sort(v, n);

	}
}
int main()
{
	int a;
	int b,n,v[100];
	int sir[10000], copie[10000];
	printf("pentru a face demo cititi 1, iar pentru grafic 2\n");
	scanf_s("%d", &a);
	if (a == 1)
	{
		printf("\npentru bubblesort-1, insertion sort-2, selection sort -3\n");
		scanf_s("%d", &b);
		printf("\ncititi numarul de elemente\n");
		scanf_s("%d", &n);
		for (int i = 0; i < n; i++)
			scanf_s("%d", &v[i]);
		demo(v, n, b);
		printf("vectorul sortat este: ");
		for (int i = 0; i < n; i++)
			printf(" %d ", v[i]);
	}
	else
	{
		//caz mediu statistic
		for (int k = 1; k <= 5; k++) //5 experimente
		{
			for (int i = 100; i <= 10000; i = i + 100)
			{
				FillRandomArray(sir, i, 10, 50000, 1, 0); //generam un array
				CopyArray(copie, sir, i); //il copiez in copie
				bubble_sort(copie, i);//apelez sortarile si copiez din nou
				CopyArray(copie, sir, i);
				insertion_sort(copie, i);
				CopyArray(copie, sir, i);
				selection_sort(copie, i);
			}
		}
		//impartim la 5 deoarece avem 5 experimente
		p.divideValues("bubblesort_atribuiri", 5);
		p.divideValues("bubblesort_comparari", 5);
		p.divideValues("bubblesort_total", 5);
		p.divideValues("insertionsort_atribuiri", 5);
		p.divideValues("insertionsort_comparari", 5);
		p.divideValues("insertionsort_total", 5);
		p.divideValues("selectionsort_atribuiri", 5);
		p.divideValues("selectionsort_comparari", 5);
		p.divideValues("selectionsort_total", 5);

		//cream grupul in grafic care sa contina toate atribuirile/comparirile/totalul intr un grafic

		p.createGroup("Mediu_Nr_atribuiri", "bubblesort_atribuiri","insertionsort_atribuiri","selectionsort_atribuiri");
		p.createGroup("Mediu_Nr_comparari", "bubblesort_comparari","insertionsort_comparari","selectionsort_comparari");
		//am adaugat un grafic cu bubble sort pt comparari pt a se vedea mai bine
		p.createGroup("Mediu_Nr_comparari_bubblesort", "bubblesort_comparari");
		p.createGroup("Mediu_Nr_total", "bubblesort_total","insertionsort_total","selectionsort_total");


		//caz favorabil
		p.reset("caz favorabil");
		for (int i = 100; i <= 10000; i = i + 100)
		{
			FillRandomArray(sir, i, 10, 50000, 1, 1);
			CopyArray(copie, sir, i);
			bubble_sort(copie, i);
			CopyArray(copie, sir, i);
			insertion_sort(copie, i);
			CopyArray(copie, sir, i);
			selection_sort(copie, i); ///am generat un array crescator si la fel ca la mediu statistic am sortat

			// tot timpul se copiaza array ul original pentru a nu apela functia cu cel original deoarece asta ar insemna sa l stricam
			}
		
		p.createGroup("Favorabil_Nr_Atribuiri", "bubblesort_atribuiri", "insertionsort_atribuiri", "selectionsort_atribuiri");
		p.createGroup("Favorabil_Nr_Atribuiri_Bubblesort", "bubblesort_atribuiri");
		p.createGroup("Favorabil_Nr_comparari", "bubblesort_comparari", "insertionsort_comparari", "selectionsort_comparari");
		p.createGroup("Favorabil_Nr_comparari_Bubblesort", "bubblesort_comparari");
		p.createGroup("Favorabil_Nr_total", "bubblesort_total", "insertionsort_total", "selectionsort_total");
		p.createGroup("Favorabil_Nr_total_Bubblesort", "bubblesort_total");

		p.reset("caz defavorabil");
		for (int i = 100; i <= 2000; i = i + 100)
		{
			FillRandomArray(sir, i, 10, 50000, 1,2);
			CopyArray(copie, sir, i);
			bubble_sort(copie, i);
			CopyArray(copie, sir, i);
			insertion_sort(copie, i);
			//cazul defavorabil la selection sort este atunci cand sirul crescator este shiftat la dreapta cu o pozitie
			int temp = copie[i - 1];
			for (int h = i - 1; h > 0;h--)
				copie[h] = copie[h - 1];
			copie[0] = temp;


			selection_sort(copie, i);


		}
		p.createGroup("defavorabil_Nr_Atribuiri", "bubblesort_atribuiri", "insertionsort_atribuiri", "selectionsort_atribuiri");
		p.createGroup("defavorabil_Nr_comparari", "bubblesort_comparari", "insertionsort_comparari", "selectionsort_comparari");
		//am mai generat doua grafice de comparari la bubble sort si insertion sort pentru a se vedea bine pe grafic
		p.createGroup("defavorabil_Nr_comparari_bubblesort", "bubblesort_comparari");
		p.createGroup("defavorabil_Nr_comparari_insertion", "insertionsort_comparari");
		p.createGroup("defavorabil_Nr_total", "bubblesort_total", "insertionsort_total", "selectionsort_total");
		p.showReport();

	}
	return 0;

}