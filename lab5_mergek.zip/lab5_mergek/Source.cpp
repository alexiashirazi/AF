#include <stdio.h>
#include <stdlib.h>
#include "profiler.h"
#include <time.h>
/*
    NUME: SHIRAZI ALEXIA
    calculatoare romana grupa 30225
    tema_5: interclasarea a k liste avand in total n elemente
    Pentru k constant complexitatea O(n), iar pt n constant (Onlogk)
    In tabelul generat de mine par foarte apropiate curbele(k=5,k=10,k=100)
    pt fiecare element se fac k operatii pt extragerea minimului. iar
    in fiecare operatie de extragere a minimului extragem elementul minim din heap si o inseram
    in lista corespunzatare in heap adica O(nlogk)
    deci complexitatea generala este de O(nlogk)
    In general, complexitatea spatiului este O(n)



*/
Profiler p("k-way merge");

int heapsize ;
typedef struct Node {
    int key;
    struct Node* next;
} Node;

void printList(Node* head) {
    while (head != NULL) {
        printf("%d ", head->key);
        head = head->next;
    }
}

void insert_first(Node** head, int cheie) {
    Node* p = (Node*)malloc(sizeof(Node));
    p->key = cheie;
    p->next = *head;
    *head = p;


}
void insert_last(Node** head, int key)
{
    Node* p = (Node*)malloc(sizeof(Node));
    p->key = key;
    p->next = NULL;
    if (*head == NULL)
    {
        *head = p;
        return;
    }
    Node* last = *head;
    while (last->next != NULL)
        last = last->next;
    last->next = p;
}

struct Node* mergetwo(struct Node* list1, struct Node* list2) {
    struct Node* mergedList = NULL;
    struct Node* tail = NULL;

    while (list1 != NULL && list2 != NULL) {
        struct Node* p = (struct Node*)malloc(sizeof(struct Node));

        if (list1->key < list2->key) {
            p->key = list1->key;
            list1 = list1->next;
        }
        else {
            p->key = list2->key;
            list2 = list2->next;
        }

        p->next = NULL;

        if (mergedList == NULL) {
            mergedList = p;
            tail = p;
        }
        else {
            tail->next = p;
            tail = p;
        }
    }

    if (list1 != NULL) {
        if (mergedList == NULL) {
            mergedList = list1;
        }
        else {
            tail->next = list1;
        }
    }
    if (list2 != NULL) {
        if (mergedList == NULL) {
            mergedList = list2;
        }
        else {
            tail->next = list2;
        }
    }

    return mergedList;
}

int left_child(int i)
{
    return 2 * i + 1;
}
int right_child(int i)
{
    return 2 * i + 2;
}
int parent(int i)
{
    return i / 2;
}
void heapify(Node** head, int k, int i, int n)
{
    
    int mic = i;
    int left = left_child(i);
    int right = right_child(i);
    if (left < k && head[left]->key < head[i]->key)
    {
        mic = left;
    }
    else
    {
        mic = i;
    }
    if (right < k && head[right]->key < head[mic]->key)
        mic = right;
    if (mic != i)
    {
        Node* aux = head[i];
        head[i] = head[mic];
        head[mic] = aux;

        heapify(head, k, mic, n);

    }
}

void heapify_perf(Node** head, int k, int i, int n, Operation op)
{
   
    int mic = i;
    int left = left_child(i);
    int right = right_child(i);
    op.count();
    if (left < k && head[left]->key < head[i]->key)
    {
        op.count();
        mic = left;
    }
    else
    {
        mic = i;
    }
    op.count();
    if (right < k && head[right]->key < head[mic]->key)
    {
        op.count();
        mic = right;
    }
    if (mic != i)
    {
        op.count(3);
        Node* aux = head[i];
        head[i] = head[mic];
        head[mic] = aux;

        heapify_perf(head, k, mic, n,op);

    }
}

void bottom_up_heap(Node** head, int n, int k) {
    heapsize = k;
    for (int i = (n / 2) - 1; i >= 0; i--) {
        heapify(head, k, i, n);
    }

}

void bottom_up_heap_perf(Node** head, int n, int k, Operation op) {
    heapsize = k;
    for (int i = (n / 2) - 1; i >= 0; i--) {
        heapify_perf(head, k, i, n,op);
    }

}

struct Node* merge_klist(Node** head, int k, int n)
{
    Node* res = NULL;
    int min;
    heapsize = k;

    //cream un heap
    bottom_up_heap(head, n, k);

   //extragem minime si le introducem in res
    while (heapsize > 0)
    {
        min = head[0]->key;
        head[0] = head[0]->next;
        insert_last(&res, min);

       
        if (head[0] == NULL)
        {
            head[0] = head[heapsize - 1];
            heapsize--;
        }

       //mentinem proprietatea de min heap
        heapify(head, heapsize, 0, n);
    }

    return res;

}

struct Node* merge_klist_perf(Node** head, int k, int n, Operation op)
{
    //aceeasi functie ca mai sus doar cu operatii
    Node* res = (Node*)malloc(n * sizeof(Node));
    res = NULL;
    int min;
    heapsize = k;

    bottom_up_heap_perf(head, n, k,op);

    
    while (heapsize > 0)
    {
        
        min = head[0]->key;
        op.count(2);
        head[0] = head[0]->next;
        insert_last(&res, min);

        op.count();

       
        if (head[0] == NULL)
        {
            op.count();
            int h = heapsize - 1;
            head[0] = head[h];
            heapsize--;
        }

        
        heapify_perf(head, heapsize, 0, n,op);
    }

    return res;

}

void generate_list(Node **lists,int n, int k)
{
    int cop_n = n;
    int cop_k = k;
    int i = 0;
    while (cop_n != 0 && cop_k != 0)
    {
        int rand_nr;
        if (cop_k == 1) //in ultima lista bagam toate elementele ramase
            rand_nr = cop_n;
        else
            rand_nr = rand() % (cop_n - cop_k + 1); ///cate elemente in a i-a lista
        if (rand_nr == 0)
            rand_nr = 1;
        cop_n = cop_n - rand_nr; //actualizam elementele
        cop_k--; //actualizam listele ramase de completat

        int* vec = (int*)malloc((rand_nr + 1) * sizeof(int));

        FillRandomArray(vec, rand_nr, 10, 5000, 0, 1);
       
        for (int j = rand_nr - 1; j >= 0; j--) {
            insert_first(&lists[i], vec[j]);
        }



        free(vec);
        i++;
    }
}
int main() {
    int choice=1;
    //printf("pentru demo apasati 1, iar pentru grafic 2\n");
    //scanf_s("%d ", &choice);

    if (choice == 1)
    {
        int n, k;
        printf("Enter the total number of elements: ");
        scanf_s("%d", &n);
        printf("Enter the number of lists: ");
        scanf_s("%d", &k);

        srand(time(NULL));

        // Allocate memory for k lists
        Node** lists = (Node**)malloc(k * sizeof(Node*));

        for (int i = 0; i < k; i++) {
            lists[i] = NULL;
        }
       

        generate_list(lists, n, k);

        // Printing the lists
        for (int i = 0; i < k; i++) {
            printf("List %d: ", i);
            printList(lists[i]);
            printf("\n");
        }
        printf("\n MERGE CU 2 LISTE\n");
        Node* rez = NULL;
        rez = mergetwo(lists[0], lists[1]);
    printList(rez);

        printf("\nMERGE CU TOATE\n");
        Node* res_total = NULL;

        res_total = merge_klist(lists, k, n);

        printList(res_total);

        //// Free the allocated memory for the linked lists
        //for (int i = 0; i < k; i++) {
        //    free(lists[i]);
        //}

        //// Free the array of lists
        //free(lists);
    }
    if(choice==2)
    {
       
        
        Node* u, * x, * y = NULL;

        //luam k constant pe 5
        for (int i = 1; i <= 30; i++)
        {
            for (int j = 100; j <= 10000; j = j + 100)
            {
              
                Node** lists = (Node**)malloc(5 * sizeof(Node*));

                for (int i = 0; i < 5; i++) {
                    lists[i] = NULL;
                }
               
                Operation op5 = p.createOperation("op5", j);
                generate_list(lists, j, 5);
               
                u = merge_klist_perf(lists, 5, j, op5);
            }

            for (int j = 100; j <= 10000; j = j + 100)
            {

                Node** lists = (Node**)malloc(10 * sizeof(Node*));

                for (int i = 0; i < 10; i++) {
                    lists[i] = NULL;
                }
               

                Operation op10 = p.createOperation("op10", j);
                generate_list(lists, j, 10);

                u = merge_klist_perf(lists, 10, j, op10);
            }
            for (int j = 100; j <= 10000; j = j + 100)
            {

                Node** lists = (Node**)malloc(100 * sizeof(Node*));

                for (int i = 0; i < 100; i++) {
                    lists[i] = NULL;
                }
                Node** copie = (Node**)malloc(100 * sizeof(Node*));

                for (int i = 0; i < 100; i++) {
                    copie[i] = NULL;
                }

                Operation op100 = p.createOperation("op100", j);
                generate_list(lists, j, 100);

                u = merge_klist_perf(lists, 100, j, op100);
            }

           
        }
        p.divideValues("op5", 30);
        p.divideValues("op10", 30);
        p.divideValues("op100", 30);
        
        p.createGroup("total_k_const", "op5", "op10", "op100");
        p.showReport();
        p.reset();
        
       //k variabil
        int n = 10000;
        for (int y = 1; y <= 100; y++) {
            for (int i = 10; i <= 500; i = i + 10)
            {
                Operation k_var = p.createOperation("k_var", i);
                Node** lists = (Node**)malloc(i * sizeof(Node*));

                for (int j = 0; j < i; j++) {
                    lists[j] = NULL;
                }
                generate_list(lists, n, i);
                merge_klist_perf(lists, i, n, k_var);
            }
        }
        p.divideValues("k_var", 100);
        p.createGroup("variabil_k", "k_var");
        p.showReport();

    }


    return 0;
}
