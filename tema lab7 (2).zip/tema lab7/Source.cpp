#include <stdio.h>
#include <stdlib.h>
#include "Profiler.h"

Profiler p("tree");
/*
* NUME SI PRENUME: SHIRAZI ALEXIA
* CALCULATOARE ROMANA SERIA A GRUPA 30225
*	BUILD TREE
*		am folosit divide et impera apeland recursiv pe jumatati
*		am luat mediana( care era (left+right)/2 si am calculat size ul pe parcurs
*		Complexitatea functiei este O(n)
* 
*	OS_Select
*		am calculat rank-ul fiecarui nod(r). 
*		daca i=r inseamna ca nodul gasit este al i lea cel mai mic element
*		daca i<r inseamna ca al i-lea cel mai mic element se afla in subarborele stang
*		daca e mai mare inseamna ca se afla in subarborele drept
*		Complexitatea algoritmului este O(lgn)
* 
* 
*	OS_delete
*		daca cheia cautata este mai mica decat root->key inseamna ca se afla in subarborele stang
*		iar daca este mai mare se afla in subarborele drept
*		daca nodul cautat are un copil sau niciunul se returneaza fratele din dreapta
*		daca nodul are doi copii, gasim cel mai mic nod din subarborele drept si copiam succesorul
*		in nodul curent
*		dupa care actualizam size-ul
*		
*/
typedef struct NodeT {
	int key;
	int size;
	struct NodeT* left;
	struct NodeT* right;
	struct NodeT* parent;
};

NodeT* BuildTree(int left, int right)
{
	//conditia de oprire
	if (left > right)
	{
		return NULL;
	}
	else
	{
		//alocam dinamic 
		NodeT* root = (NodeT*)malloc(sizeof(NodeT));
		//calculam mediana
		int mid = (left + right) / 2;
		//calculam size-ul
		root->size = right - left + 1;

		root->key = mid;

		//divide et impera
		root->left = BuildTree(left, mid - 1);
		root->right = BuildTree(mid + 1, right);
		return root;
	}
}

NodeT* OS_select(NodeT* root, int i) {


	if (root == NULL)
		return NULL;

	int r;
	if (root->left != NULL) {
		//calculam size-ul actual adaugand subarborele stang +1
		r = root->left->size + 1;
	}
	else
	{
		//daca nu exista un nod inainte inseamna ca e 1 size ul
		r = 1;
	}

	if (i == r) //daca i =r am gasit nodul dorit
		return root;
	else
	{

		if (i < r)
			//daca i<r apelam recursiv arborele stang
			return OS_select(root->left, i);
		else
			return OS_select(root->right, i - r);
	}
}

NodeT* OS_select_perf(NodeT* root, int i, Operation* opattr, Operation* opcomp) {

	if (root == NULL)
		return NULL;

	int r;
	(*opcomp).count();
	if (root->left != NULL) {
		(*opattr).count();
		r = root->left->size + 1;
	}
	else
	{
		r = 1;
	}
	if (i == r)
		return root;
	else
	{
		if (i < r)
			return OS_select_perf(root->left, i, opattr, opcomp);
		else
			return OS_select_perf(root->right, i - r, opattr, opcomp);
	}
}
void pretty_print_binary(NodeT* k, int space) {
	if (k != NULL)
	{
		int j = 0;
		while (j < space) {
			printf(" ");
			j++;
		}
		printf("%d size %d\n", k->key, k->size);

		pretty_print_binary(k->left, space + 6);
		pretty_print_binary(k->right, space + 6);
	}
}

//NodeT* OS_delete(NodeT* root, int i) {
//	if (root == NULL)
//		return root;
//	if (i < root->key)
//		root->left = OS_delete(root->left, i);
//	else
//	{
//		if (i > root->key)
//			root->right = OS_delete(root->right, i);
//		else
//		{
//			if (root->right == NULL || root->left==NULL)
//			{
//				if(root->left==NULL)
//				NodeT *p=root->
//			}
//		}
//	}
//}
NodeT* OS_delete(NodeT* root, int i) {

	if (root == NULL) {
		return NULL;  //conditia de oprire
	}

	
	if (i < root->key) {
		root->left = OS_delete(root->left, i);
	}
	else if (i > root->key) {
		root->right = OS_delete(root->right, i);
	}
	//am gasit nodul
	else {
		//daca nodul are doar un copil sau nicunul
		if (root->left == NULL) {
			NodeT* p = root->right;
			free(root);
			return p;
		}
		else if (root->right == NULL) {
			NodeT* p = root->left;
			free(root);
			return p;
		}

		// daca nodul are doi copii
		NodeT* p = root->right;
		//cautam cel mai mic nod in subarborele drept
		while (p->left != NULL) {
			p = p->left;
		}
		//copiam succesorul 
		root->key = p->key;
		//stergem recursiv
		root->right = OS_delete(root->right, p->key);
	}

	//aici actualizam size-ul dupa stergere
	

	if (root->left != NULL)
	{

		root->size = 1 + root->left->size;
	}
	else
	{

		root->size = 1;
	}

	if (root->right != NULL) {

		root->size = root->size + root->right->size;
	}
	return root;
}

NodeT* OS_delete_perf(NodeT* root, int i, Operation* opattr, Operation* opcomp) {

	if (root == NULL) {
		return NULL;  //conditia de oprire
	}

	(*opcomp).count();
	if (i < root->key) {
		(*opattr).count();
		root->left = OS_delete_perf(root->left, i, opattr, opcomp);
	}
	else {
		(*opcomp).count();
		if (i > root->key) {
			(*opattr).count();

			root->right = OS_delete_perf(root->right, i, opattr, opcomp);
		}

		else
		{
			//daca nodul are doar un copil sau nicunul
			(*opcomp).count();

			if (root->left == NULL) {
				(*opattr).count();
				NodeT* p = root->right;
				free(root);
				return p;
			}
			else {
				(*opcomp).count();

				if (root->right == NULL) {
					NodeT* p = root->left;
					(*opattr).count();
					free(root);
					return p;
				}
			}

			// daca nodul are doi copii
			(*opattr).count();
			NodeT* p = root->right;
			(*opcomp).count();
			while (p->left != NULL) {
				(*opattr).count();
				p = p->left;
			}

			(*opattr).count();
			root->key = p->key;
			(*opattr).count();
			root->right = OS_delete_perf(root->right, p->key, opattr, opcomp);
		}
	}

	//aici actualizam size-ul dupa stergere
	
	(*opcomp).count();
	if (root->left != NULL)
	{
		(*opattr).count();
		root->size = 1 + root->left->size;
	}
	else
	{
		(*opattr).count();
		root->size = 1;
	}

	(*opcomp).count();
	if (root->right != NULL) {
		(*opattr).count();
		root->size = root->size + root->right->size;
	}

	return root;
}


//void printPreorder(struct NodeT* node)
//{
//	if (node == NULL)
//		return;
//
//	// First print data of node
//	printf("%d ", node->key);
//
//	// Then recur on left subtree
//	printPreorder(node->left);
//
//	// Now recur on right subtree
//	printPreorder(node->right);
//}

int main() {

	int choice = 1;
	if (choice == 1) {
		int v[1000];
		int n;
		scanf_s("%d", &n);
		printf("\n");
		NodeT* root = (NodeT*)malloc(sizeof(NodeT));
		root = BuildTree(1, n);
		pretty_print_binary(root, 0);
		//printPreorder(root);
		printf("\n");
		int i;
		printf("input OS_select 1: ");
		scanf_s("%d", &i);

		printf("\n al %d-lea cel mai mic element este ", i);
		NodeT* elem = OS_select(root, i);
		printf("%d\n", elem->key);

		int x;
		printf("cheia care sa fie stearsa ");
		scanf_s("%d", &x);
		printf("\n");
		NodeT *o = OS_select(root, x);
		root = OS_delete(root, o->key);
		printf("arborele dupa\n");
		pretty_print_binary(root, 0);


		printf("input OS_select 2: ");
		scanf_s("%d", &i);

		printf("\n al %d-lea cel mai mic element este ", i);
		elem = OS_select(root, i);
		printf("%d\n", elem->key);

		
		printf("cheia care sa fie stearsa ");
		scanf_s("%d", &x);
		printf("\n");
		 o = OS_select(root, x);
		root = OS_delete(root, o->key);
		
		printf("arborele dupa\n");
		pretty_print_binary(root, 0);



		printf("input OS_select 3: ");
		scanf_s("%d", &i);

		printf("\n al %d-lea cel mai mic element este ", i);
		elem = OS_select(root, i);
		printf("%d\n", elem->key);


		
		printf("cheia care sa fie stearsa ");
		scanf_s("%d", &x);
		printf("\n");
		o = OS_select(root, x);
		root = OS_delete(root, o->key);
		printf("arborele dupa\n");
		pretty_print_binary(root, 0);

	}
	else
	{
		NodeT* parent = NULL;
		NodeT *root = NULL;
		int x;
		for (int j = 0; j < 10; j++)
		{
			for (int i = 100; i <= 10000; i = i + 100)
			{
				Operation opattr = p.createOperation("atribuiri", i);
				Operation opcomp = p.createOperation("comparari", i);
				root=BuildTree(1, i);
				int size = i;
				for (int k = 1; k <= size; k++)
				{
					int p = rand() % size + 1;
					NodeT* aux = OS_select_perf(root, p, &opattr, &opcomp);
					NodeT *x = OS_delete_perf(root, aux->key, &opattr, &opcomp);
					size--;
				}
			}
		}
		p.divideValues("atribuiri", 10);
		p.divideValues("comparari", 10);
		p.addSeries("total", "atribuiri", "comparari");
		p.showReport();

	}


}