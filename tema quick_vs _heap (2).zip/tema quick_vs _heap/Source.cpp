#include <stdio.h>
#include <stdlib.h>
#include "profiler.h"

Profiler p("sortari");
/*
NUME: SHIRAZI ALEXIA
UNIVERSITATEA TEHNICA DIN CLUJ NAPOCA 
CALCULATOARE GRUPA 30225
In cazul mediu la quicksort complexitatea este de O(nlogn), iar in cazul 
defavorabil O(n^2), iar favorabil este tot O(nlogn)
Din punct de vedere al spatiului Quicksort are O(nlogn), dand dovada de o alegere
foarte buna cand suntem restrictionati din punct de vedere al spatiului 
De obicei, quicksort este mai rapid decat heapsort deoarece foloseste
mult mai putin spatiu


Bubblesort are complexitatea de O(n^2) in ambele cazuri(iterativ
si recursiv) dar din punct de vedere al timpului de rulare bubblesort
iterativ este mai bun decat cel recursiv. Este mai bun si pentru ca
se foloseste mai putina memorie(la cel iterativ).
Pentru siruri mai mari varianta iterativa este mult mai buna, deoarece
se evita reapelarea. Iar datorita reapelarilor se foloseste multa memorie
ceea ce duce la executie mai lenta
 
 In concluzie, quicksort si heapsort sunt destul de asemanatoare din punct
 de vedere al complexitatii, quicksortul fiind  putin mai eficient.





*/
int partition(int v[], int st, int dr, int n)
{
	Operation opatr = p.createOperation("quicksort_atribuiri", n);
	Operation opcomp = p.createOperation("quicksort_comparari", n);
	// st=0, dr=n-1
	opatr.count();
	int x = v[dr]; //luam pivot elementul din dreapta
	int i = st - 1;
	for (int j = st; j < dr; j++)
	{
		opcomp.count();
		//comparam daca elementul este mai mic decat pivotul
		if (v[j] <= x)
		{
			i++;
			//incrementam i-ul pentru a marca ca am gasit pozitia unui element mai mic si tot interschimbam
			opatr.count();
			int aux = v[i];
			v[i] = v[j];
			v[j] = aux;
		}
	}
	opatr.count();
	//interschimbam v[i+1] cu pivotul
	int aux = v[i + 1];
	v[i + 1] = v[dr];
	v[dr] = aux;
	p.addSeries("quicksort_total", "quicksort_atribuiri", "quicksort_comparari");
	return i + 1;
}

void quicksort(int v[], int st, int dr, int n)
{
	//sortam recursiv submultimea daca stanga e mai mica decat dreapta
	if (st < dr)
	{
		//sortam recursiv partea dreapta si stanga
		int h = partition(v, st, dr, n);//aici determinam indexul de la partitionare
		quicksort(v, st, h - 1, n);
		quicksort(v, h + 1, dr, n);
	}
}

void quick_sort(int st, int dr, int v[], int n) {
	Operation opatr = p.createOperation("quick_sort_atr2", n);
	Operation opcomp = p.createOperation("quick_sort_comp2", n);
	if (st < dr) {
		int i = st;
		int j = dr;
		opatr.count();
		//luam pivotul la mijloc
		int pivot = v[(st + dr) / 2];
		//partitionam 
		while (i <= j) {
			opcomp.count();
			//cautam primul element din stanga care e mai mare decat pivotul
			while (v[i] < pivot) {
				opcomp.count();

				i++;
			}
			opcomp.count();
			//cautam primul element din dreapta care este mai mic decat pivotul
			while (v[j] > pivot) {
				opcomp.count();
				j--;
			}
			//verificam daca exista elemente din ambele parti pentru a putea face interschimbarea
			if (i <= j) {
				opatr.count();
				int aux = v[i];
				v[i] = v[j];
				v[j] = aux;
				i++;
				j--;
			}
		}
		p.addSeries("quick_sort2_total", "quick_sort_atr2", "quick_sort_comp2");
		//sortam recursiv partea stanga respectiv partea dreapta
		if (st < j) {
			quick_sort(st, j, v, n);
		}
		if (i < dr) {
			quick_sort(i, dr, v, n);
		}
	}
	
}
int left_child(int i)
{
	return 2 * i + 1;
}
int right_child(int i)
{
	return 2 * i + 2;
}
int parent(int i)
{
	return i / 2;
}
void heapify(int v[], int n, int i, int n2)
{
	Operation opatr = p.createOperation("heapsort_atribuiri",n2);//am creat operatie de atribuire
	Operation opcomp = p.createOperation("heapsort_comparari", n2); //am creat operatia de comparare
	int largest = 0;
	int left = left_child(i);
	int right = right_child(i);
	opcomp.count();
	//la fiecare pas se determina maximul dintre v[i] v[stanga] si v[dreapta]
	//si se stocheaza indexul in largest
	//daca indexul lui a[i] este in largest nu e nevoie de interschimbare
	//daca largest este diferit de i inseamna ca nodul curent nu are cea mai mare valoare 
	///comparativ cu el si copiii sai 

	if (left<n && v[left]>v[i])
	{
		largest = left;
	}
	else
	{
		largest = i;
	}
	opcomp.count();
	if (right < n && v[right] > v[largest])
		largest = right;
	if (largest != i)
	{
		opatr.count();
		int aux = v[i];
		v[i] = v[largest];
		v[largest] = aux;
		//facem apel recursiv
		heapify(v, n, largest,n2);

	}

}
void bottom_up_heap(int v[], int n)
{
	for (int i = n / 2 - 1; i >= 0; i--)
		heapify(v, n, i,n);

}
void heapsort(int v[], int n)
{
	Operation opatr = p.createOperation("heapsort_atribuiri", n); //am creat operatie de atribuire
	Operation opcomp = p.createOperation("heapsort_comparari", n); //am creat operatia de comparare
	
	bottom_up_heap(v, n);
	for (int i = n - 1; i > 0; i--)
	{
		//mergem de la sfarsit deoarece acolo este cel mai mic element si
		//facem schimb cu cel de la radacina (care e maximul)

		opatr.count();
		int aux = v[0];
		v[0] = v[i];
		v[i] = aux;
		

		heapify(v, i, 0,n);
		//se reface heap ul
	}
	p.addSeries("heapsort_total", "heapsort_atribuiri", "heapsort_comparari");



}
void bubble_sort_iterativ(int v[], int n)
{
	Operation opcomp = p.createOperation("bubble_it_comp", n);
	Operation opattr = p.createOperation("bubble_it_atr", n);

	int cop = n;
	int sortat = 1;
	do
	{
		sortat = 1;
		for (int i = 0; i < cop - 1; i++)
		{
			opcomp.count();
			if (v[i] > v[i + 1])
			{
				opattr.count();
				int  aux = v[i];
				v[i] = v[i + 1];
				v[i + 1] = aux;
				sortat = 0;

			}
		}
		cop--; ///scad n sa nu ma mai duc pana la final
	} while (!sortat);
	p.addSeries("bubble_it_total", "bubble_it_comp", "bubble_it_atr");

}
void bubble_sort_recursiv(int v[], int n, int n2)
{

	Operation opcomp = p.createOperation("bubble_rec_comp", n2);
	Operation opattr = p.createOperation("bubble_rec_atr", n2);

	if (n == 1) {
		return; // conditie de oprire..nu sortam sir cu un element
	}

	int sortat = 0;
	for (int j = 0; j < n - 1; j++) {
		// comparam elementele si le interschimbam daca e cazul
		opcomp.count();
		if (v[j] > v[j + 1]) {
			opattr.count();
			int aux = v[j + 1];
			v[j + 1] = v[j];
			v[j] = aux;
			sortat = 1;
		}
	}

	if (sortat == 0)
		return; // daca nu s -au facut interschimbari 

	p.addSeries("bubble_rec_total", "bubble_rec_comp", "bubble_rec_atr");
	// Recursive call to sort the remaining elements.
	bubble_sort_recursiv(v, n - 1, n2);

}
int main()
{
	//demo

	int v[100] = { 0 };
	int sir[10001], copie[10001];
	int m, n;
	printf("pentru demo apasati 1, iar pentru grafic 2\n");
	scanf_s("%d", &m);
	if (m == 1)
	{
		printf("\ncititi numarul de elemente\n");
		scanf_s("%d", &n);

		for (int i = 0; i < n; i++)
			scanf_s("%d", &v[i]);

		quicksort(v, 0, n - 1, n);
		//heapsort(v, n);
		printf("\n vectorul sortat este: ");
		for (int i = 0; i < n; i++)
			printf("%d ", v[i]);
	}
	else

	{

		//caz mediu statistic quicksort mediu
		for (int t = 0; t < 5; t++)
		{
			for (int i = 100; i <= 10000; i = i + 100)
			{
				FillRandomArray(sir, i, 10, 50000, 1, 0);
				CopyArray(copie, sir, i);
				quicksort(copie, 0, i - 1, i);
			}
		}
		p.divideValues("quicksort_atribuiri", 5);
		p.divideValues("quicksort_comparari", 5);
		p.divideValues("quicksort_total", 5);


		p.reset("quicksort_caz_defav_vs_caz_favorabil");

		p.reset("heapsort_vs_quicksort");

		for (int t = 0; t < 5; t++)
		{
			for (int i = 100; i <= 10000; i = i + 100)
			{
				FillRandomArray(sir, i, 10, 50000, 1, 0);
				CopyArray(copie, sir, i);
				heapsort(copie, i);
				CopyArray(copie, sir, i);
				quicksort(copie, 0, i - 1, i);
			}
		}
		p.divideValues("heapsort_atribuiri", 5);
		p.divideValues("heapsort_comparari", 5);
		p.divideValues("heapsort_total", 5);
		p.divideValues("quicksort_atribuiri", 5);
		p.divideValues("quicksort_comparari", 5);
		p.divideValues("quicksort_total", 5);

		p.createGroup("Mediu_quick_heap_atribuiri", "heapsort_atribuiri", "quicksort_atribuiri");
		p.createGroup("Mediu_quick_heap_comparari", "heapsort_comparari", "quicksort_comparari");
		p.createGroup("Mediu_quick_heap_total", "heapsort_total", "quicksort_total");

		p.reset("quicksort_cazfav");

		for (int i = 100; i <= 10000; i = i + 100)
		{
			FillRandomArray(sir, i, 10, 50000, 1, 1);
			CopyArray(copie, sir, i);
			quick_sort(0, i - 1, copie, i);
		}
		
		
		p.createGroup("quicksort_favorabil_atribuiri", "quick_sort_atr2");
		p.createGroup("quicksort_favorabil_comparari", "quick_sort_comp2");
		p.createGroup("quicksort_favorabil_total", "quick_sort2_total");


		p.reset("quicksort_cazdefav");

		for (int i = 100; i <= 10000; i = i + 100)
		{
			FillRandomArray(sir, i, 10, 50000, 1,1);
			quicksort(v, 0, i - 1, i);


		}
		p.createGroup("quicksort_defavorabil_atribuiri", "quicksort_atribuiri");
		p.createGroup("quicksort_defavorabil_comparari", "quicksort_comparari");
		p.createGroup("quicksort_defavorabil_total", "quicksort_total");

		p.reset("bubblesort_rec_vs_it");
		for (int t = 0; t < 5; t++)
		{
			for (int i= 100;i<= 10000;i= i+100)
			{
				FillRandomArray(sir, i, 10, 50000, 1, 0);
				CopyArray(copie, sir, i);
				bubble_sort_iterativ(copie, i);
				CopyArray(copie, sir, i);
				bubble_sort_recursiv(copie, i,i);
			}
		}
	
		p.divideValues("bubble_it_comp", 5);
		p.divideValues("bubble_it_atr", 5);
		p.divideValues("bubble_it_total", 5);
		p.divideValues("bubble_rec_comp", 5);
		p.divideValues("bubble_rec_atr", 5);
		p.divideValues("bubble_rec_total", 5);

		p.createGroup("Mediu_bubble_atribuiri", "bubble_it_atr", "bubble_rec_atr");
		p.createGroup("Mediu_bubble_comparari", "bubble_it_comp", "bubble_rec_comp");
		p.createGroup("Mediu_bubble_total","bubble_it_total", "bubble_rec_total");
	/*	p.reset("timp bubblesort");*/
	
			for (int i = 100; i <= 4000; i = i + 100)
			{
				FillRandomArray(sir, i, 10, 50000, 0, 0);
				
				p.startTimer("timp_bubble_iterativ", i);
				for (int test = 0; test < 100; test++)
				{
					
					CopyArray(copie, sir, i);

					bubble_sort_iterativ(copie, i);
				}
					p.stopTimer("timp_bubble_iterativ", i);

					p.startTimer("timp_bubble_recursiv", i);
					for (int test = 0; test < 100; test++)
					{
						CopyArray(copie, sir, i);

						bubble_sort_recursiv(copie, i, i);
					}
					p.stopTimer("timp_bubble_recursiv", i);
				
			}
		
		p.divideValues("timp_bubble_iterativ", 100);
		p.divideValues("timp_bubble_recursiv", 100);
		p.createGroup("Bubble_sort_timp", "timp_bubble_iterativ", "timp_bubble_recursiv");
		
		p.showReport();


	}

	return 0;
}